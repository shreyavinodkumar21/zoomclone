
# How to use this Website






1. copy and paste below Link on Your Browser

```bash
  https://zoomclone-mahesh.herokuapp.com/
```
2. create the meeting code and join the meeting

3. send the room code to your friend

4. start conversation



## Freatures

1. Create meeting
2. Leave the meeting
3. Turn on/off the video 
4. Turn on/off the audio
5. Group chat







